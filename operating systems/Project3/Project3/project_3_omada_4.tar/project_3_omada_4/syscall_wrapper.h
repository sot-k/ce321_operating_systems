long alloc_mem_syscall_wrapper(void);

long free_mem_syscall_wrapper(void);